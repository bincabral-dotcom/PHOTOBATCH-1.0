# PHOTOBATCH

Aplicativo Android para edição rápida de fotos, seleção de miniaturas e exportação em lote.

## O que o app faz

- Ajusta contraste, brilho, exposição, realces, sombras, brancos, pretos, temperatura, matiz, vibração e saturação.
- Mostra uma prévia atualizada enquanto os controles são alterados.
- Usa o botão **Auto** para sugerir uma correção tonal e de cor a partir da própria imagem.
- Seleciona até 50 imagens pelo seletor seguro do Android e permite alternar entre elas pelas miniaturas.
- Salva uma cópia da foto atual ou aplica os mesmos controles em todas as fotos selecionadas.
- Grava as cópias em **Imagens/PHOTOBATCH** e preserva os arquivos originais.

## Compilar pelo GitHub

1. Extraia o conteúdo deste ZIP na raiz do repositório GitHub.
2. Crie a pasta `.github/workflows` na raiz do repositório.
3. Salve o arquivo `android.yml` fornecido separadamente dentro dessa pasta.
4. Envie os arquivos extraídos e o workflow para o GitHub. A aba **Actions** compilará o APK de depuração.
5. Baixe o arquivo `app-debug.apk` no artefato **PHOTOBATCH-debug-apk** da execução concluída.

O projeto foi preparado para compilar no GitHub Actions com Gradle 8.13 e Java 17. A compilação produz um APK de depuração para instalação e avaliação; publicação na Play Store exige assinatura própria.

## Observação sobre o Auto

O Auto calcula uma sugestão local usando a distribuição de tons e o equilíbrio de cor da foto. É um ajuste automático inspirado no fluxo de editores fotográficos; os resultados podem variar conforme a imagem.
