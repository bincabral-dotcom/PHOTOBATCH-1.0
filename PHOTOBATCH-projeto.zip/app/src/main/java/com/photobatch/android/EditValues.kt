package com.photobatch.android

data class EditValues(
    val contrast: Int = 0,
    val brightness: Int = 0,
    val exposure: Int = 0,
    val highlights: Int = 0,
    val shadows: Int = 0,
    val whites: Int = 0,
    val blacks: Int = 0,
    val temperature: Int = 0,
    val tint: Int = 0,
    val vibrance: Int = 0,
    val saturation: Int = 0,
) {
    fun isDefault(): Boolean = this == EditValues()
}
