package com.photobatch.android

import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = PhotoBatchColors) {
                PhotoBatchApp()
            }
        }
    }
}

private val PhotoBatchColors: ColorScheme = darkColorScheme(
    primary = Accent,
    onPrimary = Color(0xFF0B211C),
    secondary = Color(0xFFF8C96B),
    background = Canvas,
    surface = Panel,
    onBackground = TextPrimary,
    onSurface = TextPrimary,
)

@Composable
private fun PhotoBatchApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val photos = remember { mutableStateListOf<PhotoChoice>() }
    val snackbar = remember { SnackbarHostState() }

    var selectedIndex by remember { mutableIntStateOf(0) }
    var values by remember { mutableStateOf(EditValues()) }
    var sourceBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var previewBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var loadingPhotos by remember { mutableStateOf(false) }
    var loadingPreview by remember { mutableStateOf(false) }
    var exporting by remember { mutableStateOf(false) }
    var exportStatus by remember { mutableStateOf("") }
    var confirmBatch by remember { mutableStateOf(false) }

    val activePhoto = photos.getOrNull(selectedIndex)

    val photoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia(50),
    ) { selectedUris ->
        if (selectedUris.isNotEmpty()) {
            scope.launch {
                loadingPhotos = true
                try {
                    val knownUris = photos.map { it.uri.toString() }.toMutableSet()
                    var added = 0
                    for (uri in selectedUris) {
                        if (!knownUris.add(uri.toString())) continue
                        val thumbnail = PhotoFiles.decode(context, uri, THUMBNAIL_SIZE) ?: continue
                        photos.add(PhotoChoice(uri, thumbnail))
                        added++
                    }
                    if (photos.size == added && photos.isNotEmpty()) selectedIndex = 0
                    snackbar.showSnackbar(
                        if (added == 0) "Essas fotos já estão na seleção."
                        else "$added foto(s) adicionada(s).",
                    )
                } catch (error: Exception) {
                    snackbar.showSnackbar(error.message ?: "Não foi possível carregar as fotos.")
                } finally {
                    loadingPhotos = false
                }
            }
        }
    }

    LaunchedEffect(activePhoto?.uri) {
        sourceBitmap = null
        previewBitmap = null
        loadingPreview = activePhoto != null
        try {
            if (activePhoto != null) {
                sourceBitmap = PhotoFiles.decode(context, activePhoto.uri, PREVIEW_SIZE)
            }
        } catch (error: Exception) {
            snackbar.showSnackbar(error.message ?: "Não foi possível abrir esta foto.")
        } finally {
            loadingPreview = false
        }
    }

    LaunchedEffect(sourceBitmap, values) {
        val source = sourceBitmap ?: return@LaunchedEffect
        previewBitmap = withContext(Dispatchers.Default) {
            ImageProcessor.render(source, values)
        }
    }

    fun startExport(uris: List<Uri>) {
        if (uris.isEmpty() || exporting) return
        scope.launch {
            exporting = true
            exportStatus = "Preparando fotos…"
            try {
                val total = PhotoFiles.export(context, uris, values) { completed, count ->
                    exportStatus = "Salvando $completed de $count…"
                }
                snackbar.showSnackbar(
                    if (total == 1) "Foto salva em Imagens/PHOTOBATCH."
                    else "$total fotos salvas em Imagens/PHOTOBATCH.",
                )
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Exception) {
                snackbar.showSnackbar(error.message ?: "A exportação não foi concluída.")
            } finally {
                exporting = false
                exportStatus = ""
            }
        }
    }

    val launchPicker = {
        photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
    }

    Scaffold(
        containerColor = Canvas,
        contentWindowInsets = WindowInsets.safeDrawing,
        snackbarHost = { SnackbarHost(hostState = snackbar) },
    ) { insets ->
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .padding(insets)
                .padding(horizontal = 16.dp, vertical = 8.dp),
        ) {
            val wideLayout = maxWidth >= 760.dp
            Column(modifier = Modifier.fillMaxSize()) {
                AppHeader(
                    photoCount = photos.size,
                    enabled = !loadingPhotos && !exporting,
                    onSelectPhotos = launchPicker,
                )
                Spacer(Modifier.height(12.dp))

                if (wideLayout) {
                    Row(
                        modifier = Modifier.weight(1f),
                        horizontalArrangement = Arrangement.spacedBy(18.dp),
                    ) {
                        Column(
                            modifier = Modifier.weight(1.1f),
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            PreviewCard(
                                bitmap = previewBitmap,
                                hasPhoto = activePhoto != null,
                                isLoading = loadingPhotos || loadingPreview,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .heightIn(max = 430.dp)
                                    .aspectRatio(1.25f),
                                onSelectPhotos = launchPicker,
                            )
                            PhotoStrip(
                                photos = photos,
                                selectedIndex = selectedIndex,
                                onSelect = { selectedIndex = it },
                            )
                        }
                        AdjustmentPanel(
                            values = values,
                            onValuesChange = { values = it },
                            modifier = Modifier.weight(0.9f),
                        )
                    }
                } else {
                    PreviewCard(
                        bitmap = previewBitmap,
                        hasPhoto = activePhoto != null,
                        isLoading = loadingPhotos || loadingPreview,
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 300.dp)
                            .aspectRatio(1.28f),
                        onSelectPhotos = launchPicker,
                    )
                    Spacer(Modifier.height(10.dp))
                    PhotoStrip(
                        photos = photos,
                        selectedIndex = selectedIndex,
                        onSelect = { selectedIndex = it },
                    )
                    Spacer(Modifier.height(6.dp))
                    AdjustmentPanel(
                        values = values,
                        onValuesChange = { values = it },
                        modifier = Modifier.weight(1f),
                    )
                }

                if (exporting) {
                    Text(
                        text = exportStatus,
                        color = Accent,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(bottom = 4.dp),
                    )
                }
                ActionBar(
                    enabled = activePhoto != null && !loadingPhotos && !exporting,
                    batchEnabled = photos.size > 1 && !loadingPhotos && !exporting,
                    onAuto = {
                        val source = sourceBitmap
                        if (source != null) {
                            scope.launch {
                                values = withContext(Dispatchers.Default) {
                                    ImageProcessor.automatic(source)
                                }
                                snackbar.showSnackbar("Ajuste automático aplicado.")
                            }
                        }
                    },
                    onSave = { activePhoto?.let { startExport(listOf(it.uri)) } },
                    onBatch = { confirmBatch = true },
                )
            }
        }
    }

    if (confirmBatch) {
        AlertDialog(
            onDismissRequest = { confirmBatch = false },
            containerColor = Panel,
            title = { Text("Aplicar em lote", color = TextPrimary, fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    "Salvar cópias com estes ajustes para ${photos.size} fotos selecionadas? A foto aberta também será incluída.",
                    color = TextSecondary,
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        confirmBatch = false
                        startExport(photos.map { it.uri })
                    },
                ) {
                    Text("Aplicar lote", color = Accent, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { confirmBatch = false }) {
                    Text("Cancelar", color = TextSecondary)
                }
            },
        )
    }
}

@Composable
private fun AppHeader(
    photoCount: Int,
    enabled: Boolean,
    onSelectPhotos: () -> Unit,
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Box(
            modifier = Modifier
                .size(42.dp)
                .clip(RoundedCornerShape(13.dp))
                .background(Accent.copy(alpha = 0.14f)),
            contentAlignment = Alignment.Center,
        ) {
            Text("PB", color = Accent, fontWeight = FontWeight.Black, fontSize = 16.sp)
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(
                "PHOTOBATCH",
                color = TextPrimary,
                fontSize = 18.sp,
                lineHeight = 20.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 0.5.sp,
            )
            Text(
                if (photoCount == 0) "EDIÇÃO DE FOTOS" else "$photoCount foto(s) selecionada(s)",
                color = TextSecondary,
                fontSize = 10.sp,
                letterSpacing = 1.1.sp,
            )
        }
        Button(
            onClick = onSelectPhotos,
            enabled = enabled,
            shape = RoundedCornerShape(13.dp),
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = Accent,
                contentColor = Color(0xFF0B211C),
                disabledContainerColor = Panel,
                disabledContentColor = TextMuted,
            ),
        ) {
            Text("＋ Selecionar", fontSize = 13.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun PreviewCard(
    bitmap: Bitmap?,
    hasPhoto: Boolean,
    isLoading: Boolean,
    modifier: Modifier = Modifier,
    onSelectPhotos: () -> Unit,
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(22.dp))
            .background(Panel)
            .border(1.dp, Border, RoundedCornerShape(22.dp)),
        contentAlignment = Alignment.Center,
    ) {
        when {
            bitmap != null -> Image(
                bitmap = bitmap.asImageBitmap(),
                contentDescription = "Pré-visualização da foto editada",
                contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxSize(),
            )
            isLoading -> CircularProgressIndicator(color = Accent, strokeWidth = 2.dp)
            hasPhoto -> Text(
                "Não foi possível carregar a foto",
                color = TextSecondary,
                fontSize = 14.sp,
            )
            else -> Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.padding(20.dp),
            ) {
                Text("◫", color = Accent, fontSize = 42.sp)
                Text("Sua próxima foto começa aqui", color = TextPrimary, fontWeight = FontWeight.SemiBold)
                Text(
                    "Escolha uma ou várias imagens para editar.",
                    color = TextSecondary,
                    fontSize = 13.sp,
                )
                TextButton(onClick = onSelectPhotos) {
                    Text("Escolher fotos", color = Accent, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun PhotoStrip(
    photos: List<PhotoChoice>,
    selectedIndex: Int,
    onSelect: (Int) -> Unit,
) {
    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text(
                "FOTOS",
                color = TextSecondary,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.4.sp,
            )
            Text(
                if (photos.isEmpty()) "Toque em Selecionar para começar" else "Toque numa miniatura para editar",
                color = TextMuted,
                fontSize = 10.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        if (photos.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(62.dp)
                    .clip(RoundedCornerShape(15.dp))
                    .background(Panel.copy(alpha = 0.65f)),
                contentAlignment = Alignment.CenterStart,
            ) {
                Text(
                    "As fotos escolhidas aparecerão aqui",
                    color = TextMuted,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(horizontal = 14.dp),
                )
            }
        } else {
            LazyRow(
                modifier = Modifier.fillMaxWidth().height(68.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                itemsIndexed(photos, key = { _, photo -> photo.uri.toString() }) { index, photo ->
                    Box(
                        modifier = Modifier
                            .size(width = 70.dp, height = 64.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .border(
                                width = if (index == selectedIndex) 2.dp else 1.dp,
                                color = if (index == selectedIndex) Accent else Border,
                                shape = RoundedCornerShape(12.dp),
                            )
                            .clickable { onSelect(index) },
                    ) {
                        Image(
                            bitmap = photo.thumbnail.asImageBitmap(),
                            contentDescription = "Foto ${index + 1}",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize().padding(2.dp).clip(RoundedCornerShape(9.dp)),
                        )
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .padding(5.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color(0xA6000000))
                                .padding(horizontal = 5.dp, vertical = 2.dp),
                        ) {
                            Text("${index + 1}", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

private data class SliderEntry(
    val label: String,
    val value: Int,
    val onChange: (Int) -> Unit,
)

@Composable
private fun AdjustmentPanel(
    values: EditValues,
    onValuesChange: (EditValues) -> Unit,
    modifier: Modifier = Modifier,
) {
    val lightControls = listOf(
        SliderEntry("Contraste", values.contrast) { onValuesChange(values.copy(contrast = it)) },
        SliderEntry("Brilho", values.brightness) { onValuesChange(values.copy(brightness = it)) },
        SliderEntry("Exposição", values.exposure) { onValuesChange(values.copy(exposure = it)) },
        SliderEntry("Realces", values.highlights) { onValuesChange(values.copy(highlights = it)) },
        SliderEntry("Sombras", values.shadows) { onValuesChange(values.copy(shadows = it)) },
        SliderEntry("Brancos", values.whites) { onValuesChange(values.copy(whites = it)) },
        SliderEntry("Pretos", values.blacks) { onValuesChange(values.copy(blacks = it)) },
    )
    val colorControls = listOf(
        SliderEntry("Temperatura", values.temperature) { onValuesChange(values.copy(temperature = it)) },
        SliderEntry("Matiz", values.tint) { onValuesChange(values.copy(tint = it)) },
        SliderEntry("Vibração", values.vibrance) { onValuesChange(values.copy(vibrance = it)) },
        SliderEntry("Saturação", values.saturation) { onValuesChange(values.copy(saturation = it)) },
    )

    Column(modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text("AJUSTES", color = TextSecondary, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
            TextButton(
                onClick = { onValuesChange(EditValues()) },
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
            ) {
                Text("Zerar", color = Accent, fontSize = 12.sp)
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(18.dp)).background(Panel),
            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(1.dp),
        ) {
            item { SectionLabel("LUZ") }
            items(lightControls) { entry -> AdjustmentSlider(entry) }
            item { SectionLabel("COR") }
            items(colorControls) { entry -> AdjustmentSlider(entry) }
        }
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(
        text,
        color = Accent,
        fontSize = 10.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.4.sp,
        modifier = Modifier.padding(top = 6.dp, bottom = 2.dp),
    )
}

@Composable
private fun AdjustmentSlider(entry: SliderEntry) {
    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text(entry.label, color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Medium)
            val displayValue = if (entry.value > 0) "+${entry.value}" else entry.value.toString()
            Text(displayValue, color = TextSecondary, fontSize = 12.sp)
        }
        Slider(
            value = entry.value.toFloat(),
            onValueChange = { entry.onChange(it.roundToInt()) },
            valueRange = -100f..100f,
            steps = 199,
            colors = SliderDefaults.colors(
                thumbColor = Accent,
                activeTrackColor = Accent,
                inactiveTrackColor = Color(0xFF3C4A49),
                activeTickColor = Color(0xFF0B211C),
                inactiveTickColor = Color(0xFF66706E),
            ),
            modifier = Modifier.fillMaxWidth().height(32.dp),
        )
    }
}

@Composable
private fun ActionBar(
    enabled: Boolean,
    batchEnabled: Boolean,
    onAuto: () -> Unit,
    onSave: () -> Unit,
    onBatch: () -> Unit,
) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(top = 10.dp, bottom = 2.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        OutlinedButton(
            onClick = onAuto,
            enabled = enabled,
            shape = RoundedCornerShape(14.dp),
            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 11.dp),
            border = BorderStroke(1.dp, Border),
        ) {
            Text("Auto", color = if (enabled) Accent else TextMuted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
        OutlinedButton(
            onClick = onSave,
            enabled = enabled,
            shape = RoundedCornerShape(14.dp),
            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 11.dp),
            border = BorderStroke(1.dp, Border),
            modifier = Modifier.weight(1f),
        ) {
            Text("Salvar foto", color = if (enabled) TextPrimary else TextMuted, fontSize = 12.sp, maxLines = 1)
        }
        Button(
            onClick = onBatch,
            enabled = batchEnabled,
            shape = RoundedCornerShape(14.dp),
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 11.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = Accent,
                contentColor = Color(0xFF0B211C),
                disabledContainerColor = Panel,
                disabledContentColor = TextMuted,
            ),
            modifier = Modifier.weight(1.2f),
        ) {
            Text("Lote", fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
    }
}

private const val THUMBNAIL_SIZE = 220
private const val PREVIEW_SIZE = 1500

private val Canvas = Color(0xFF101719)
private val Panel = Color(0xFF1A2325)
private val Border = Color(0xFF2B3838)
private val Accent = Color(0xFF72E0C4)
private val TextPrimary = Color(0xFFF2F6F4)
private val TextSecondary = Color(0xFFA4B2AE)
private val TextMuted = Color(0xFF6F7C79)
