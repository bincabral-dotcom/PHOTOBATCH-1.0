package com.photobatch.android

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class PhotoChoice(
    val uri: Uri,
    val thumbnail: Bitmap,
)

object PhotoFiles {
    suspend fun decode(context: Context, uri: Uri, maxDimension: Int): Bitmap? =
        withContext(Dispatchers.IO) {
            decodeBlocking(context, uri, maxDimension)
        }

    fun decodeBlocking(context: Context, uri: Uri, maxDimension: Int): Bitmap? {
        val source = ImageDecoder.createSource(context.contentResolver, uri)
        return ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
            val longestSide = maxOf(info.size.width, info.size.height).coerceAtLeast(1)
            val scale = minOf(1f, maxDimension.toFloat() / longestSide)
            val targetWidth = (info.size.width * scale).toInt().coerceAtLeast(1)
            val targetHeight = (info.size.height * scale).toInt().coerceAtLeast(1)
            decoder.setTargetSize(targetWidth, targetHeight)
            decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
        }
    }

    suspend fun export(
        context: Context,
        imageUris: List<Uri>,
        values: EditValues,
        onProgress: suspend (completed: Int, total: Int) -> Unit,
    ): Int = withContext(Dispatchers.IO) {
        val resolver = context.contentResolver
        imageUris.forEachIndexed { index, uri ->
            val original = decodeBlocking(context, uri, EXPORT_MAX_DIMENSION)
                ?: throw IOException("Não foi possível abrir uma das fotos.")
            val edited = try {
                withContext(Dispatchers.Default) {
                    ImageProcessor.render(original, values)
                }
            } finally {
                original.recycle()
            }

            try {
                val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                val name = "PHOTOBATCH_${timestamp}_${(index + 1).toString().padStart(2, '0')}.jpg"
                val row = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, name)
                    put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                    put(MediaStore.Images.Media.RELATIVE_PATH, "${Environment.DIRECTORY_PICTURES}/PHOTOBATCH")
                    put(MediaStore.Images.Media.IS_PENDING, 1)
                }
                val destination = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, row)
                    ?: throw IOException("Não foi possível criar o arquivo de saída.")
                try {
                    val output = resolver.openOutputStream(destination, "w")
                        ?: throw IOException("Não foi possível gravar a foto.")
                    output.use {
                        if (!edited.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, it)) {
                            throw IOException("A exportação da foto falhou.")
                        }
                    }
                    val complete = ContentValues().apply {
                        put(MediaStore.Images.Media.IS_PENDING, 0)
                    }
                    resolver.update(destination, complete, null, null)
                } catch (error: Throwable) {
                    resolver.delete(destination, null, null)
                    throw error
                }
            } finally {
                edited.recycle()
            }

            withContext(Dispatchers.Main.immediate) {
                onProgress(index + 1, imageUris.size)
            }
        }
        imageUris.size
    }

    private const val EXPORT_MAX_DIMENSION = 3000
    private const val JPEG_QUALITY = 94
}
