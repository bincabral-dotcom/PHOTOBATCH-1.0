package com.photobatch.android

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

object ImageProcessor {
    fun render(source: Bitmap, values: EditValues): Bitmap {
        val width = source.width
        val height = source.height
        val pixels = IntArray(width * height)
        source.getPixels(pixels, 0, width, 0, 0, width, height)

        val exposureFactor = 2.0.pow(values.exposure / 50.0).toFloat()
        val brightnessOffset = values.brightness / 100f * 0.18f
        val contrastFactor = 1f + values.contrast / 100f * 0.8f
        val temperature = values.temperature / 100f
        val tint = values.tint / 100f
        val saturationScale = 1f + values.saturation / 100f
        val vibrance = values.vibrance / 100f
        val output = IntArray(pixels.size)

        for (index in pixels.indices) {
            val pixel = pixels[index]
            var red = Color.red(pixel) / 255f
            var green = Color.green(pixel) / 255f
            var blue = Color.blue(pixel) / 255f

            // Warm/cool white balance and green/magenta tint.
            red *= 1f + temperature * 0.18f + tint * 0.055f
            green *= 1f - tint * 0.11f
            blue *= 1f - temperature * 0.18f + tint * 0.055f

            red = red * exposureFactor + brightnessOffset
            green = green * exposureFactor + brightnessOffset
            blue = blue * exposureFactor + brightnessOffset

            red = (red - 0.5f) * contrastFactor + 0.5f
            green = (green - 0.5f) * contrastFactor + 0.5f
            blue = (blue - 0.5f) * contrastFactor + 0.5f

            val luminance = (0.2126f * red + 0.7152f * green + 0.0722f * blue).coerceIn(0f, 1f)
            val highlightMask = smoothstep(0.38f, 1f, luminance)
            val shadowMask = 1f - smoothstep(0.04f, 0.62f, luminance)
            val whiteMask = smoothstep(0.70f, 1f, luminance)
            val blackMask = 1f - smoothstep(0.02f, 0.34f, luminance)
            val tonalShift =
                values.highlights / 100f * -0.23f * highlightMask +
                    values.shadows / 100f * 0.20f * shadowMask +
                    values.whites / 100f * 0.15f * whiteMask +
                    values.blacks / 100f * 0.15f * blackMask

            red = (red + tonalShift).coerceIn(0f, 1f)
            green = (green + tonalShift).coerceIn(0f, 1f)
            blue = (blue + tonalShift).coerceIn(0f, 1f)

            val maximum = max(red, max(green, blue))
            val minimum = min(red, min(green, blue))
            val delta = maximum - minimum
            if (delta > 0.00001f && maximum > 0f) {
                val originalSaturation = delta / maximum
                var hue = when {
                    maximum == red -> 60f * (((green - blue) / delta) % 6f)
                    maximum == green -> 60f * (((blue - red) / delta) + 2f)
                    else -> 60f * (((red - green) / delta) + 4f)
                }
                if (hue < 0f) hue += 360f
                val adjustedSaturation = (
                    originalSaturation * saturationScale +
                        vibrance * (1f - originalSaturation).pow(2) * 0.8f
                    ).coerceIn(0f, 1f)
                val chroma = maximum * adjustedSaturation
                val hueSection = hue / 60f
                val secondary = chroma * (1f - abs(hueSection % 2f - 1f))
                val (r1, g1, b1) = when (hueSection.toInt()) {
                    0 -> Triple(chroma, secondary, 0f)
                    1 -> Triple(secondary, chroma, 0f)
                    2 -> Triple(0f, chroma, secondary)
                    3 -> Triple(0f, secondary, chroma)
                    4 -> Triple(secondary, 0f, chroma)
                    else -> Triple(chroma, 0f, secondary)
                }
                val match = maximum - chroma
                red = r1 + match
                green = g1 + match
                blue = b1 + match
            }

            output[index] = Color.argb(
                Color.alpha(pixel),
                (red.coerceIn(0f, 1f) * 255f).toInt(),
                (green.coerceIn(0f, 1f) * 255f).toInt(),
                (blue.coerceIn(0f, 1f) * 255f).toInt(),
            )
        }

        return Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888).apply {
            setPixels(output, 0, width, 0, 0, width, height)
        }
    }

    fun automatic(source: Bitmap): EditValues {
        val pixels = IntArray(source.width * source.height)
        source.getPixels(pixels, 0, source.width, 0, 0, source.width, source.height)
        val histogram = IntArray(256)
        var count = 0
        var redTotal = 0.0
        var greenTotal = 0.0
        var blueTotal = 0.0
        var saturationTotal = 0.0
        val sampleStride = max(1, pixels.size / 16_000)

        for (index in pixels.indices step sampleStride) {
            val pixel = pixels[index]
            val red = Color.red(pixel) / 255f
            val green = Color.green(pixel) / 255f
            val blue = Color.blue(pixel) / 255f
            val luminance = (0.2126f * red + 0.7152f * green + 0.0722f * blue).coerceIn(0f, 1f)
            histogram[(luminance * 255f).toInt()]++
            redTotal += red
            greenTotal += green
            blueTotal += blue
            val maximum = max(red, max(green, blue))
            val minimum = min(red, min(green, blue))
            saturationTotal += if (maximum == 0f) 0f else (maximum - minimum) / maximum
            count++
        }
        if (count == 0) return EditValues()

        fun percentile(fraction: Double): Float {
            val target = ((count - 1) * fraction).toInt()
            var cumulative = 0
            for (bin in histogram.indices) {
                cumulative += histogram[bin]
                if (cumulative > target) return bin / 255f
            }
            return 1f
        }

        val low = percentile(0.05)
        val middle = percentile(0.50).coerceAtLeast(0.04f)
        val high = percentile(0.95)
        val spread = (high - low).coerceAtLeast(0.16f)
        val exposureStops = (ln(0.48f / middle) / ln(2f)).coerceIn(-0.9f, 0.9f)
        val averageRed = (redTotal / count).toFloat()
        val averageGreen = (greenTotal / count).toFloat()
        val averageBlue = (blueTotal / count).toFloat()
        val averageSaturation = (saturationTotal / count).toFloat()

        return EditValues(
            contrast = (((0.78f / spread) - 1f) * 70f).toInt().coerceIn(-15, 30),
            exposure = (exposureStops * 50f).toInt().coerceIn(-45, 45),
            highlights = if (high > 0.86f) (-((high - 0.86f) * 150f)).toInt().coerceIn(-35, 0) else 4,
            shadows = if (low < 0.13f) (((0.13f - low) * 180f)).toInt().coerceIn(0, 24) else 0,
            whites = ((0.96f - high) * 90f).toInt().coerceIn(-20, 16),
            blacks = ((0.035f - low) * 110f).toInt().coerceIn(-18, 12),
            temperature = ((averageBlue - averageRed) * 110f).toInt().coerceIn(-18, 18),
            tint = ((averageGreen - (averageRed + averageBlue) / 2f) * 100f).toInt().coerceIn(-12, 12),
            vibrance = if (averageSaturation < 0.22f) 18 else if (averageSaturation > 0.48f) -8 else 8,
        )
    }

    private fun smoothstep(edge0: Float, edge1: Float, value: Float): Float {
        val t = ((value - edge0) / (edge1 - edge0)).coerceIn(0f, 1f)
        return t * t * (3f - 2f * t)
    }
}
